/**
 * 
 */
/**
 * 
 */
module pudding {
	requires java.desktop;
	requires java.sql;
}