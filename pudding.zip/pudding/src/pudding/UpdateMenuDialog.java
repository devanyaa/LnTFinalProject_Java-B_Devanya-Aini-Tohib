package pudding;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class UpdateMenuDialog extends JDialog {
    private JTextField txtKodeMenu, txtNamaMenu, txtHargaMenu, txtStokMenu;
    private JButton btnUpdate;

    public UpdateMenuDialog(JFrame parent) {
        super(parent, "Update Menu", true);
        setSize(400, 250); // Increased size for better layout
        setLayout(new GridLayout(5, 2, 10, 10)); // Using GridLayout with 5 rows and 2 columns

        txtKodeMenu = new JTextField(10);
        txtNamaMenu = new JTextField(10);
        txtHargaMenu = new JTextField(10);
        txtStokMenu = new JTextField(10);
        btnUpdate = new JButton("Update");

        // Add components in pairs: Label and TextField
        add(new JLabel("Kode Menu:"));
        add(txtKodeMenu);
        add(new JLabel("New Nama Menu:"));
        add(txtNamaMenu);
        add(new JLabel("New Harga Menu:"));
        add(txtHargaMenu);
        add(new JLabel("New Stok Menu:"));
        add(txtStokMenu);
        add(new JLabel()); // Placeholder for alignment
        add(btnUpdate);

        btnUpdate.addActionListener(this::updateAction);
        setVisible(true);
    }

    private void updateAction(ActionEvent event) {
        String kode = txtKodeMenu.getText();
        String nama = txtNamaMenu.getText();
        double harga = Double.parseDouble(txtHargaMenu.getText());
        int stok = Integer.parseInt(txtStokMenu.getText());
        try (Connection conn = Koneksi.getConnection()) {
            String sql = "UPDATE menu SET nama_menu = ?, harga_menu = ?, stok_menu = ? WHERE kode_menu = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, nama);
            statement.setDouble(2, harga);
            statement.setInt(3, stok);
            statement.setString(4, kode);
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(this, "Menu item updated successfully!");
                dispose(); // Close dialog after successful update
            } else {
                JOptionPane.showMessageDialog(this, "No menu item was found with the provided code.", "Update Failed", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
