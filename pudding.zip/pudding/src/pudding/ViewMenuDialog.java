package pudding;
import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class ViewMenuDialog extends JDialog {
    private JTextArea textArea;

    public ViewMenuDialog(JFrame parent) {
        super(parent, "View Menus", true);
        setSize(400, 300);
        setLayout(new BorderLayout());

        textArea = new JTextArea();
        textArea.setEditable(false);
        add(new JScrollPane(textArea), BorderLayout.CENTER);

        loadMenus();
        setVisible(true);
    }

    private void loadMenus() {
        try (Connection conn = Koneksi.getConnection()) {
            String sql = "SELECT * FROM menu";
            Statement statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            StringBuilder builder = new StringBuilder();
            while (resultSet.next()) {
                builder.append("Kode Menu: ").append(resultSet.getString("kode_menu")).append("\n");
                builder.append("Nama Menu: ").append(resultSet.getString("nama_menu")).append("\n");
                builder.append("Harga Menu: ").append(resultSet.getDouble("harga_menu")).append("\n");
                builder.append("Stok Menu: ").append(resultSet.getInt("stok_menu")).append("\n\n");
            }
            textArea.setText(builder.toString());
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
