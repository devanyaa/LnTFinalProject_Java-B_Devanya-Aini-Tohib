package pudding;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class CreateMenuDialog extends JDialog {
    private JTextField txtKodeMenu, txtNamaMenu, txtHargaMenu, txtStokMenu;
    private JButton btnInsert;

    public CreateMenuDialog(JFrame parent) {
        super(parent, "Insert New Menu", true);
        setSize(350, 200);
        setLayout(new GridLayout(5, 2, 10, 10));  // Set grid layout with 5 rows and 2 columns, with gaps of 10

        // Initialize fields
        txtKodeMenu = new JTextField(10);
        txtNamaMenu = new JTextField(10);
        txtHargaMenu = new JTextField(10);
        txtStokMenu = new JTextField(10);
        btnInsert = new JButton("Insert");

        // Add components to the dialog
        add(new JLabel("Kode Menu:"));
        add(txtKodeMenu);
        add(new JLabel("Nama Menu:"));
        add(txtNamaMenu);
        add(new JLabel("Harga Menu:"));
        add(txtHargaMenu);
        add(new JLabel("Stok Menu:"));
        add(txtStokMenu);
        add(new JLabel());  // Placeholder for alignment
        add(btnInsert);

        // Action listener for the insert button
        btnInsert.addActionListener(this::insertAction);

        // Make the dialog visible
        setVisible(true);
    }

    private void insertAction(ActionEvent event) {
        String kode = txtKodeMenu.getText();
        String nama = txtNamaMenu.getText();
        double harga = Double.parseDouble(txtHargaMenu.getText());
        int stok = Integer.parseInt(txtStokMenu.getText());
        try (Connection conn = Koneksi.getConnection()) {
            String sql = "INSERT INTO menu (kode_menu, nama_menu, harga_menu, stok_menu) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, kode);
            statement.setString(2, nama);
            statement.setDouble(3, harga);
            statement.setInt(4, stok);
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "A new menu item was inserted successfully!");
                dispose();  // Close the dialog after successful insertion
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
