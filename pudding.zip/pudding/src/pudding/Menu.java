package pudding;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Menu extends JFrame {
    private JButton btnCreate, btnView, btnUpdate, btnDelete;

    public Menu() {
        super("PT Pudding Menu Management");
        initializeUI();
    }

    private void initializeUI() {
        setLayout(new FlowLayout());
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        btnCreate = new JButton("Create Menu");
        btnView = new JButton("View Menus");
        btnUpdate = new JButton("Update Menu");
        btnDelete = new JButton("Delete Menu");

        btnCreate.addActionListener(e -> new CreateMenuDialog(this));
        btnView.addActionListener(e -> new ViewMenuDialog(this));
        btnUpdate.addActionListener(e -> new UpdateMenuDialog(this));
        btnDelete.addActionListener(e -> new DeleteMenuDialog(this));

        add(btnCreate);
        add(btnView);
        add(btnUpdate);
        add(btnDelete);

        setVisible(true);
    }

    public static void main(String[] args) {
        new Menu();
    }
}
