package pudding;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class DeleteMenuDialog extends JDialog {
    private JTextField txtKodeMenu;
    private JButton btnDelete;

    public DeleteMenuDialog(JFrame parent) {
        super(parent, "Delete Menu", true);
        setSize(300, 150);
        setLayout(new FlowLayout());

        txtKodeMenu = new JTextField(10);
        btnDelete = new JButton("Delete");

        add(new JLabel("Kode Menu:"));
        add(txtKodeMenu);
        add(btnDelete);

        btnDelete.addActionListener(this::deleteAction);
        setVisible(true);
    }

    private void deleteAction(ActionEvent event) {
        String kode = txtKodeMenu.getText();
        try (Connection conn = Koneksi.getConnection()) {
            String sql = "DELETE FROM menu WHERE kode_menu = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, kode);
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(this, "Menu item deleted successfully!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "No menu item was found with the provided code.", "Deletion Failed", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
